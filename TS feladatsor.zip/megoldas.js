//1. feladat
function DiakInfo(nev, csoport, tipus) {
    var diakadatai = nev + " [Team" + csoport + "] - ";
    if (tipus == true) {
        diakadatai += "Junior Frontend";
    }
    else {
        diakadatai += "Webprogramozó";
    }
    return diakadatai;
}
document.write(DiakInfo("Minta Márton", 8, true));
//2. feladat
function SzovegesErtekeles(jegy) {
    if (jegy == 5) {
        return ["példás", "példás"];
    }
    else if (jegy == 4) {
        return ["jó", "jó"];
    }
    else if (jegy == 3) {
        return ["változó", "változó"];
    }
    else if (jegy == 2) {
        return ["hanyag", "rossz"];
    }
    else {
        return ["hibás bemeneti érték", ""];
    }
}
document.write("<hr>Szorgalom és magatartás: " + SzovegesErtekeles(2));
//3. feladat
function HarommalOsztas(tomb) {
    var harommaloszthatok = [];
    for (var i = 0; i < tomb.length; i++) {
        if (tomb[i] % 3 == 0) {
            harommaloszthatok.push(tomb[i]);
        }
    }
    return harommaloszthatok;
}
var oszthato = HarommalOsztas([10, 23, 12, 24, 31, 33, 42, 20]);
document.write("<hr>Ebben a tömbben " + oszthato.length + "db, 3-mal osztható szám van: " + oszthato);
//4. feladat
function Nyeroszamok(mennyiseg, alsoHatar, felsoHatar) {
    var szamok = [];
    for (var i = 0; i < mennyiseg; i++) {
        var generaltSzam = Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
        var szerepele = false;
        for (var j = 0; j < szamok.length; j++) {
            if (generaltSzam == szamok[j]) {
                szerepele = true;
            }
        }
        if (szerepele == true) {
            i--;
        }
        else {
            szamok.push(generaltSzam);
        }
    }
    return szamok;
}
document.write("<hr>" + Nyeroszamok(5, 1, 90));
