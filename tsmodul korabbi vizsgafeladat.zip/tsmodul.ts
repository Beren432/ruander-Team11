//1. feladat
function Rng(alsoHatar: number, felsoHatar: number): number {
    return Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
}
document.write("" + Rng(1, 100));

//2. feladat
function TombGenerator(meret: number, alsoHatar: number, felsoHatar: number): number[] {
    var tomb: number[] = [];
    for (let i: number = 0; i < meret; i++) {
        tomb.push(Rng(alsoHatar, felsoHatar));
    }
    return tomb;
}
document.write("<hr>" + TombGenerator(10, 1, 100));

//3. feladat
function Duplazo(VizsgaltTomb: number[]): number[] {
    for (let i: number = 0; i < VizsgaltTomb.length; i++) {
        VizsgaltTomb[i] = VizsgaltTomb[i] * 2;
    }
    return VizsgaltTomb;
}
var ujtomb: number[] = TombGenerator(10, 1, 100);
document.write("<hr>" + ujtomb + " - duplázva: " + Duplazo(ujtomb));

//4. feladat
function PrimekSzama(VizsgaltTomb: number[]): number {
    var primszamok: number = 0;
    for (let i: number = 0; i < VizsgaltTomb.length; i++) {
        var osztokszama: number = 0;
        for (let j: number = 0; j < VizsgaltTomb.length; j++) {
            if (VizsgaltTomb[i] % j == 0) {
                osztokszama++;
            }
        }
        if (osztokszama == 2) {
            primszamok++;
        }
    }
    return primszamok;
}
var ujtomb: number[] = TombGenerator(10, 1, 100);
document.write("<hr>" + ujtomb + " - prímszámok mennyisége: " + PrimekSzama(ujtomb));

//5. feladat
function EgyediElemek(VizsgaltTomb: number[]): number[] {
    var egyedielemek: number[] = [];
    for (let i: number = 0; i < VizsgaltTomb.length; i++) {
        var szerepele:boolean=false;
        for (let j: number = 0; j < VizsgaltTomb.length; j++){
            if(i!=j && VizsgaltTomb[i]==VizsgaltTomb[j]){
                szerepele=true;
            }
        }
        if(szerepele==false){
            egyedielemek.push(VizsgaltTomb[i]);
        }
    }
    return egyedielemek;
}
var ujtomb: number[] = TombGenerator(10, 1, 20);
document.write("<hr>" + ujtomb + " - egyedi elemek: " + EgyediElemek(ujtomb));