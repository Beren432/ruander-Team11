//1)Készíts egy függvényt ami a kapott szövegben megszámolja, mennyi ékezetes betű van benne.
function EkezetesBetukSzama(modositandoSzoveg: string): number {
    let ekezetszam: number = 0;
    let ekezetesbetuk: string[] = ["á", "é", "í", "ó", "ő", "ú", "ű"];
    for (let i: number = 0; i < modositandoSzoveg.length; i++) {
        for (let j: number = 0; j < ekezetesbetuk.length; j++) {
            if (modositandoSzoveg[i] == ekezetesbetuk[j]) {
                ekezetszam++;
            }
        }
    }
    return ekezetszam;
}
console.log(EkezetesBetukSzama("Lám kék az ég."));

//2)Készíts egy függvényt, ami a bemenetinek kapott szövegből camelCase szöveget hoz létre!
function camelCaseGenerator(modositandoSzoveg: string): string {
    let keszSzoveg: string = "";
    for (let i: number = 0; i < modositandoSzoveg.length; i++) {
        if (modositandoSzoveg[i] != " ") {
            keszSzoveg += modositandoSzoveg[i];
        }
        else{
            keszSzoveg+=modositandoSzoveg[i+1].toUpperCase();
            i++;
        }
    }
    return keszSzoveg;
}
console.log(camelCaseGenerator("egy függvényt ami a bemenetinek kapott szövegből"));

//3)Készíts egy függvényt, ami kiírja melyek a prímszámok a vizsgált tömbödben, ha van ilyen, ha nincs akkor térjen vissza a "Nincs prímszám a tömbben" szöveggel
function PrimLista(vizsgaltTomb: number[]): string[] {
    let eredmeny: string[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let osztokszama = 0;
        for (let j: number = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j == 0) {
                osztokszama++;
            }
        }
        if (osztokszama == 2) {
            eredmeny.push(vizsgaltTomb[i].toString());
        }
    }
    if (eredmeny.length == 0) {
        eredmeny[0] = "Nincs prímszám a tömbben";
    }
    return eredmeny;

}
console.log(PrimLista([2, 3, 5, 6, 7, 8, 9, 10]));
console.log(PrimLista([20, 30, 50, 60, 70, 80, 90, 10]));