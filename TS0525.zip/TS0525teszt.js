function ujVisszajelzoSor(tesztneve, visszajelzes) {
    var table = document.querySelector("#testTable");
    var adatSor = table.insertRow(1);
    var tesztNeveMezo = adatSor.insertCell(0);
    var visszajelzesMezo = adatSor.insertCell(1);
    tesztNeveMezo.innerHTML = `${tesztneve}`;
    visszajelzesMezo.innerHTML = `${visszajelzes}`;
}


function teszt01() {
    try {
        if (EkezetesBetukSzama("Lám kék az ég.")==3){
            ujVisszajelzoSor("Ékezetes betűk száma - függvény", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Ékezetes betűk száma - függvény", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Ékezetes betűk száma - függvény", "HIBA");
    }
}

function teszt02() {
    try {
        if (camelCaseGenerator("egy függvényt ami a bemenetinek kapott szövegből")=="egyFüggvénytAmiABemenetinekKapottSzövegből"){
            ujVisszajelzoSor("Camel case - függvény", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Camel case - függvény", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Camel case - függvény", "HIBA");
    }
}

function teszt03() {
    try {
        let eredm1=PrimLista([2, 3, 5, 6, 7, 8, 9, 1]);
        if (eredm1.length==4){
            ujVisszajelzoSor("Primlista - függvény 1", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Primlista - függvény 1", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Primlista - függvény 1", "HIBA");
    }
}

function teszt04() {
    try {
        let eredm2=PrimLista([20, 30, 50, 60, 70, 80, 90, 10]);
        if (eredm2[0]=="Nincs prímszám a tömbben"){
            ujVisszajelzoSor("Primlista - függvény 2", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Primlista - függvény 2", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Primlista - függvény 2", "HIBA");
    }
}
teszt01();
teszt02();
teszt03();
teszt04();