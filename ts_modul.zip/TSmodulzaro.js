//1. feladat
function MegtettUt(sebesseg, ido) {
    return sebesseg * ido;
}
//2. feladat
function HosegriadoSzint(nap1, nap2, nap3) {
    if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27) {
        return 3;
    }
    else if (nap1 >= 25 && nap2 >= 25 && nap3 >= 25) {
        return 2;
    }
    else if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) {
        return 1;
    }
    else {
        return 0;
    }
}
//3. feladat
function OszthatoSzamok(oszto, vizsgaltTomb) {
    var oszhatoszamok = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % oszto == 0) {
            oszhatoszamok++;
        }
    }
    return oszhatoszamok;
}
//4. feladat
function Erettsegi(pontok) {
    var osszpontszam = 0;
    var jegy = 0;
    for (var i = 0; i < pontok.length; i++) {
        osszpontszam += pontok[i];
    }
    if (osszpontszam < 40) {
        jegy = 1;
    }
    else if (osszpontszam < 60) {
        jegy = 2;
    }
    else if (osszpontszam < 80) {
        jegy = 3;
    }
    else if (osszpontszam < 120) {
        jegy = 4;
    }
    else {
        jegy = 5;
    }
    return [osszpontszam, jegy];
}
//5. feladat
function LeetKod(vizsgaltSzoveg) {
    var atalakitottSzoveg = "";
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        if (vizsgaltSzoveg[i] == "i" || vizsgaltSzoveg[i] == "I") {
            atalakitottSzoveg += "1";
        }
        else if (vizsgaltSzoveg[i] == "o" || vizsgaltSzoveg[i] == "O") {
            atalakitottSzoveg += "0";
        }
        else if (vizsgaltSzoveg[i] == "a" || vizsgaltSzoveg[i] == "A") {
            atalakitottSzoveg += "4";
        }
        else if (vizsgaltSzoveg[i] == "e" || vizsgaltSzoveg[i] == "E") {
            atalakitottSzoveg += "3";
        }
        else {
            atalakitottSzoveg += vizsgaltSzoveg[i];
        }
    }
    return atalakitottSzoveg;
}
