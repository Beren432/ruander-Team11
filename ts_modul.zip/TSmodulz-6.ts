//6. feladat
const snookerInfo:string[] = ["52;Akani Sunny;Thaif�ld;118500",
    "7;Allen Mark;�szak-�rorsz�g;681000",
    "72;Anda Zhang;K�na;44750",
    "76;Astley John;Anglia;40000",
    "73;Baird Sam;Anglia;44750",
    "13;Bingham Stuart;Anglia;345500",
    "97;Bingyu Chang;K�na;6750",
    "28;Brecel Luca;Belgium;179000",
    "79;Brown Jordan;�szak-�rorsz�g;29000",
    "78;Burden Alfred;Anglia;32000",
    "50;Carrington Stuart;Anglia;121750",
    "16;Carter Ali;Anglia;289000",
    "81;Carty Ashley;Anglia;22750",
    "86;Chandler Harvey;Anglia;14475",
    "83;Chuan Leong Thor;Malajzia;16500",
    "84;Clarke Jamie Rhys;Wales;15500",
    "63;Craigie Sam;Anglia;78500",
    "94;Dale Dominic;Wales;8750",
    "41;Davis Mark;Anglia;145725",
    "20;Day Ryan;Wales;244250",
    "18;Ding Junhui;K�na;270250",
    "64;Doherty Ken;�rorsz�g;77250",
    "29;Donaldson Scott;Sk�cia;176750",
    "21;Dott Graeme;Sk�cia;237750",
    "66;Dunn Mike;Anglia;74750",
    "53;Ebdon Peter;Anglia;111750",
    "88;Feilong Chen;K�na;13500",
    "22;Ford Tom;Anglia;212250",
    "57;Fu Marco;Hong Kong;104250",
    "51;Georgiou Michael;Ciprus;119600",
    "11;Gilbert David;Anglia;412000",
    "33;Gould Martin;Anglia;160250",
    "99;Grace David;Anglia;6750",
    "24;Guodong Xiao;K�na;211600",
    "61;Hamilton Anthony;Anglia;92250",
    "25;Haotian Lyu;K�na;191750",
    "10;Hawkins Barry;Anglia;427250",
    "91;Heathcote Louis;Anglia;10750",
    "6;Higgins John;Sk�cia;743000",
    "59;Higginson Andrew;Anglia;96250",
    "60;Highfield Liam;Anglia;96000",
    "89;Hirani Kishan;Wales;13350",
    "44;Holt Michael;Anglia;133500",
    "70;Honghao Luo;K�na;65000",
    "95;Jiahui Si;K�na;7500",
    "87;Jiankang Zhang;K�na;13600",
    "71;Jones Jak;Wales;54250",
    "48;Joyce Mark;Anglia;125750",
    "30;King Mark;Anglia;166500",
    "100;Langning Bai;K�na;5000",
    "92;Lee Andy;Anglia;9500",
    "43;Li Hang;K�na;138000",
    "36;Liang Wenbo;K�na;154500",
    "80;Lines Oliver;Anglia;28000",
    "12;Lisowski Jack;Anglia;392250",
    "34;Maflin Kurt;Norv�gia;158600",
    "14;Maguire Stephen;Sk�cia;316000",
    "96;Mann Mitchell;Anglia;7500",
    "32;McGill Anthony;Sk�cia;160500",
    "54;McManus Alan;Sk�cia;111250",
    "85;Miah Hammad;Anglia;15475",
    "39;Milkins Robert;Anglia;149600",
    "8;Murphy Shaun;Anglia;506500",
    "62;Ning Lu;K�na;87250",
    "67;O'Brien Fergal;�rorsz�g;70600",
    "68;O'Connor Joe;Anglia;69750",
    "42;O'Donnell Martin;Anglia;145250",
    "2;O'Sullivan Ronnie;Anglia;1116000",
    "65;Pengfei Tian;K�na;75750",
    "15;Perry Joe;Anglia;292500",
    "23;Robertson Jimmy;Anglia;211725",
    "5;Robertson Neil;Ausztr�lia;834500",
    "35;Saengkham Noppon;Thaif�ld;157000",
    "4;Selby Mark;Anglia;863000",
    "27;Selt Matthew;Anglia;180350",
    "49;Sijun Yuan;K�na;123000",
    "74;Slessor Elliot;Anglia;43500",
    "75;Steadman Craig;Anglia;40500",
    "90;Stefanow Adam;Lengyelorsz�g;12500",
    "46;Stevens Matthew;Wales;129750",
    "1;Trump Judd;Anglia;1270500",
    "37;Un-Nooh Thepchaiya;Thaif�ld;151225",
    "98;Ursenbacher Alexander;Sv�jc;6750",
    "31;Vafaei Hossein;Ir�n;161500",
    "45;Wakelin Chris;Anglia;129975",
    "26;Walden Ricky;Anglia;182750",
    "77;Walker Lee;Wales;33000",
    "82;Wattana James;Thaif�ld;17500",
    "56;Wells Daniel;Wales;104250",
    "58;White Michael;Wales;98250",
    "3;Williams Mark;Wales;1048250",
    "55;Williams Robbie;Anglia;107500",
    "19;Wilson Gary;Anglia;261100",
    "9;Wilson Kyren;Anglia;470500",
    "40;Woollaston Ben;Anglia;146350",
    "47;Xintong Zhao;K�na;125750",
    "69;Xiwen Mei;K�na;68000",
    "17;Yan Bingtao;K�na;285000",
    "93;Zhengyi Fan;K�na;9500",
    "38;Zhou Yuelong;K�na;150250",
]

interface snooker {
    helyezes: number;
    nev: string;
    orszag: string;
    nyeremeny: number;
}

function Objektumfeltolto(feltoltendoElem: string[]): snooker[] {
    var beolvasottAdatok:snooker[]=[];
    for(let i:number=0;i<feltoltendoElem.length;i++){
        let darabolandoSor:string[]=feltoltendoElem[i].split(";");
        let objektum:snooker={
            helyezes:Number(darabolandoSor[0]),
            nev:darabolandoSor[1],
            orszag:darabolandoSor[2],
            nyeremeny:Number(darabolandoSor[3])
        };
        beolvasottAdatok.push(objektum);
    }
    return beolvasottAdatok;
}
var snookerAdatok:snooker[]=Objektumfeltolto(snookerInfo);

function LegtobbNyeremeny(vizsgaltObjektum:snooker[]):number{
    let maxnyeremeny:number=vizsgaltObjektum[0].nyeremeny;
    for (let i:number=0;i<vizsgaltObjektum.length;i++){
        if (vizsgaltObjektum[i].nyeremeny>maxnyeremeny){
            maxnyeremeny=vizsgaltObjektum[i].nyeremeny;
        }
    }
    return maxnyeremeny;
}