const eredmenyek: string[] = [
    "1 1 atletika kalapacsvetes",
    "1 1 uszas 400m_gyorsuszas",
    "1 1 birkozas kotott_fogas_legsuly",
    "1 1 torna talajtorna",
    "1 1 torna felemas_korlat",
    "1 1 vivas kardvivas_egyeni",
    "1 1 okolvivas nagyvaltosuly",
    "1 1 uszas 200m_melluszas",
    "1 1 birkozas kotott_fogas_valtosuly",
    "1 1 uszas 100m_gyorsuszas",
    "1 1 sportloveszet onmukodo_sportpisztoly",
    "1 15 labdarugas ferfi_csapat",
    "1 3 ottusa ferfi_csapat",
    "1 6 vivas kardvivas_csapat",
    "1 5 uszas 4x100m_gyorsuszo_valto",
    "1 13 vizilabda ferfi_csapat",
    "2 1 ottusa ottusa_egyeni",
    "2 1 vivas torvivas_egyeni",
    "2 1 vivas kardvivas_egyeni",
    "2 1 sportloveszet onmukodo_sportpisztoly",
    "2 1 uszas 400m_gyorsuszas",
    "2 1 uszas 200m_melluszas",
    "2 1 kajakkenu kenu_egyes_10000m",
    "2 1 kajakkenu kajak_egyes_1000m",
    "2 1 birkozas kotott_fogas_pehelysuly",
    "2 8 torna noi_osszetett_csapat",
    "3 1 sportloveszet sportpisztoly",
    "3 1 vivas kardvivas_egyeni",
    "3 1 atletika tavolugras",
    "3 1 birkozas szabad_fogas_kozepsuly",
    "3 1 torna felemas_korlat",
    "3 1 torna osszetett_egyeni",
    "3 1 torna gerenda",
    "3 1 torna talajtorna",
    "3 1 atletika kalapacsvetes",
    "3 1 atletika 50km_gyaloglas",
    "3 1 ottusa ottusa_egyeni",
    "3 1 uszas 100m_gyorsuszas",
    "3 4 atletika 4x100m_valtofutas",
    "3 2 kajakkenu kenu_kettes_10000m",
    "3 8 torna keziszer_csapat",
    "3 6 vivas torvivas_csapat",
    "4 1 torna gerenda",
    "4 1 uszas 200m_mell",
    "4 1 birkozas kotottfogas_felnehezsuly",
    "4 1 torna talaj",
    "4 1 birkozas kotottfogas_kozepsuly",
    "4 1 birkozas kotottfogas_konnyusuly",
    "5 1 okolvivas pehelysuly",
    "5 1 okolvivas konnyusuly",
    "5 1 uszas 100m_gyors",
    "5 1 atletika diszkoszvetes",
    "5 1 vivas parbajtor_egyeni",
    "5 2 kajak kenu kenu_kettes_1000m",
    "5 2 kerekparozas ketuleses_verseny",
    "5 4 uszas 4 200m_gyorsvalto",
    "5 5 vivas parbajtor_csapat",
    "6 1 birkozas kotottfogas_legsuly",
    "6 1 kajak kenu kajak_egyes_500m",
    "6 1 torna osszetett_egyeni",
    "6 1 kerekparozas repuloverseny",
    "6 1 uszas 400m_gyors",
    "6 1 torna felemaskorlat",
    "6 8 torna osszetett_csapat",
];

interface helsinki {
    helyezes: number;
    sportolok: number;
    sportag: string;
    versenyszam: string;
}

function Objektumfeltolto(feltoltendoElem: string[]): helsinki[] {
    var beolvasottAdatok: helsinki[] = [];
    for (let i: number = 0; i < feltoltendoElem.length; i++) {
        let darabolandoSor: string[] = feltoltendoElem[i].split(" ");
        let objektum: helsinki = {
            helyezes: Number(darabolandoSor[0]),
            sportolok: Number(darabolandoSor[1]),
            sportag: darabolandoSor[2],
            versenyszam: darabolandoSor[3]
        };
        beolvasottAdatok.push(objektum);
    }
    return beolvasottAdatok;
}
var helsinkiadatok: helsinki[] = Objektumfeltolto(eredmenyek);

//3.feladat: hány 1-3. helyezés van
function elsoharomhelyezes(helsinkiadatok: helsinki[]): number {
    let helyezesekszama: number = 0;
    for (let i: number = 0; i < helsinkiadatok.length; i++) {
        if (helsinkiadatok[i].helyezes < 4) {
            helyezesekszama++;
        }
    }
    return helyezesekszama;
}
document.write("Pontszerző helyezések száma: " + elsoharomhelyezes(helsinkiadatok));

//4.feladat: érmek száma
function ermekszama(helsinkiadatok: helsinki[]): [number, number, number] {
    let helyezesekszama: [number, number, number] = [0,0,0];
    for (let i: number = 0; i < helsinkiadatok.length; i++) {
        if (helsinkiadatok[i].helyezes == 1) {
            helyezesekszama[0]++;
        }
        else if (helsinkiadatok[i].helyezes == 2) {
            helyezesekszama[1]++;
        }
        else if (helsinkiadatok[i].helyezes == 3) {
            helyezesekszama[2]++;
        }
        else { }
    }
    return helyezesekszama;
}
let eremszam: number[] = ermekszama(helsinkiadatok);
document.write("<hr>Arany: " + eremszam[0] + ", ezüst: " + eremszam[1] + ", bronz: " + eremszam[2]);

//5.feladat: pontok
function pontosszesito(helsinkiadatok: helsinki[]): number {
    let pontosszeg: number = 0;
    for (let i: number = 0; i < helsinkiadatok.length; i++) {
        if (helsinkiadatok[i].helyezes == 1) {
            pontosszeg += 7;
        }
        else if (helsinkiadatok[i].helyezes == 2) {
            pontosszeg += 5;
        }
        else if (helsinkiadatok[i].helyezes == 3) {
            pontosszeg += 4;
        }
        else if (helsinkiadatok[i].helyezes == 4) {
            pontosszeg += 3;
        }
        else if (helsinkiadatok[i].helyezes == 5) {
            pontosszeg += 2;
        }
        else {
            pontosszeg += 1;
        }
    }
    return pontosszeg;
}
document.write("<hr>Pontok száma: "+pontosszesito(helsinkiadatok));

//6.feladat:úszás vagy torna
function uszastorna(helsinkiadatok: helsinki[]): void {
    let uszasermek: number = 0;
    let tornaermek: number = 0;
    for (let i: number = 0; i < helsinkiadatok.length; i++) {
        if(helsinkiadatok[i].sportag=="uszas" && helsinkiadatok[i].helyezes<4){
            uszasermek++;
        }
        else if(helsinkiadatok[i].sportag=="torna" && helsinkiadatok[i].helyezes<4){
            tornaermek++;
        }
    }
    if (uszasermek>tornaermek){
        document.write("<hr>Úszásból volt több érem.")
    }
    else if (uszasermek<tornaermek){
        document.write("<hr>Tornából volt több érem.")
    }
    else{
        document.write("<hr>Egyenlő volt az érmek száma.")
    }
}
uszastorna(helsinkiadatok);

//7.feladat:legtöbb sportoló
function legtobbsportolo(helsinkiadatok: helsinki[]): number {
    let maxsportolo: number = 0;
    for (let i: number = 0; i < helsinkiadatok.length; i++) {
        if (helsinkiadatok[i].helyezes<4){
            if (helsinkiadatok[i].sportolok>helsinkiadatok[maxsportolo].sportolok){
                maxsportolo=i;
            }
        }
    }
    return maxsportolo;
}
let sportag=legtobbsportolo(helsinkiadatok);
document.write("<hr>A legtöbb sportoló helyezése: "+helsinkiadatok[sportag].helyezes);
document.write("<br>A legtöbb sportoló sportága: "+helsinkiadatok[sportag].sportag);
document.write("<br>A legtöbb sportoló száma: "+helsinkiadatok[sportag].sportolok);
document.write("<br>A legtöbb sportoló versenyszáma: "+helsinkiadatok[sportag].versenyszam);